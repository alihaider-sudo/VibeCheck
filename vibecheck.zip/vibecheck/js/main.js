/* =====================================================
   VibeCheck - main.js
   Three small features. Each one starts with an "if"
   so it only runs on the page that needs it.
   1. Explore: filter articles by category
   2. Lab: "Spot the Mistake" quiz
   3. About: demonstration contact form
   ===================================================== */


/* ---------- 1. EXPLORE: filter articles ---------- */
const filterBar = document.querySelector(".filter-bar");

if (filterBar) {
  const buttons = filterBar.querySelectorAll(".filter-button");
  const articles = document.querySelectorAll("[data-category]");
  const status = document.querySelector(".filter-status");

  // The bar is hidden in the HTML. We only show it when JavaScript works,
  // so visitors without JavaScript never see buttons that do nothing.
  filterBar.hidden = false;

  buttons.forEach(function (button) {
    button.addEventListener("click", function () {
      const chosen = button.dataset.filter;   // reads data-filter="..."
      let shown = 0;

      // Mark only the clicked button as pressed
      buttons.forEach(function (other) {
        other.setAttribute("aria-pressed", String(other === button));
      });

      // Show matching articles, hide the rest
      articles.forEach(function (article) {
        const matches = chosen === "all" || article.dataset.category === chosen;
        article.hidden = !matches;
        if (matches) {
          shown = shown + 1;
        }
      });

      status.textContent = "Showing " + shown + (shown === 1 ? " article" : " articles");
    });
  });
}


/* ---------- 2. LAB: Spot the Mistake quiz ---------- */
const questions = document.querySelectorAll(".quiz-question");

if (questions.length > 0) {
  const scoreText = document.querySelector(".quiz-score");

  function updateScore() {
    let correct = 0;
    questions.forEach(function (question) {
      if (question.dataset.result === "correct") {
        correct = correct + 1;
      }
    });
    scoreText.textContent = "Score: " + correct + " / " + questions.length;
  }

  questions.forEach(function (question) {
    const checkButton = question.querySelector(".quiz-check");
    const feedback = question.querySelector(".quiz-feedback");
    const verdict = feedback.querySelector(".quiz-verdict");
    const explanation = feedback.querySelector(".quiz-explanation");

    checkButton.addEventListener("click", function () {
      const chosen = question.querySelector("input:checked");
      feedback.hidden = false;

      // Nothing selected yet
      if (!chosen) {
        verdict.textContent = "Choose an answer first.";
        explanation.hidden = true;
        return;
      }

      explanation.hidden = false;

      // data-answer on the question holds the correct option (a, b or c)
      if (chosen.value === question.dataset.answer) {
        verdict.textContent = "Correct.";
        question.dataset.result = "correct";
      } else {
        verdict.textContent = "Not quite. Read the explanation, then try again.";
        question.dataset.result = "incorrect";
      }

      updateScore();
    });
  });
}


/* ---------- 3. ABOUT: demonstration contact form ---------- */
const contactForm = document.querySelector("#contact-form");

if (contactForm) {
  const formMessage = document.querySelector("#form-message");

  contactForm.addEventListener("submit", function (event) {
    event.preventDefault();   // stop the browser from reloading the page

    // There is no server behind this form, so we say so honestly.
    formMessage.textContent = "Demonstration only: this form is not connected to a server, so nothing was sent.";
    formMessage.hidden = false;
    contactForm.reset();
  });
}
